# Operating-Systems-Memories
My worst fucking nightmare. May I never have to look at this fuckery ever again.
